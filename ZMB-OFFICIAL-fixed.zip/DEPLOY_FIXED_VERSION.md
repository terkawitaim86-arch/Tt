# ZMB OFFICIAL — corrected project package

## Included fixes
- Added moderation aliases: `,b` → ban, `,k` → kick, `,c` → clear, `,to` → timeout, `,w` → warn.
- Preserved the existing `,purge` alias for clear and the `,mute` alias for timeout.
- Made command/alias registration case-insensitive and added collision warnings.
- Scoped command cooldowns to the command's canonical name, so aliases cannot bypass cooldowns.
- Scoped XP cooldowns to the server and user instead of a shared user object.
- Added a JavaScript syntax check script and Node.js 20+ engine requirement.

## Upload to Bot-Hosting.net
1. Stop the bot.
2. Back up the current files first.
3. Upload/extract this ZIP into the directory containing `index.js` and `package.json`, replacing the existing project files.
4. Do not upload `node_modules`; run the host's install step or `npm install` if needed.
5. In the host's environment/variables panel, ensure `DISCORD_TOKEN`, `SUPABASE_URL`, and `SUPABASE_SERVICE_ROLE_KEY` are set. The code also supports your older `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` variables, but the anon key may not have permission for all bot database operations. Never paste these secrets into chat or commit them to GitHub.
6. Start the bot and check the console for `Loaded ... commands`.
7. In a test channel, try `,help`, `,b @member test`, `,k @member test`, `,c 2`, `,to @member 1m test`, and `,w @member test`. Test moderation commands only with a trusted test account and appropriate permissions.

## Important
This package does not include live credentials and has not been connected to your Discord server or Supabase project here. Database migrations may still be required if your current Supabase tables do not match the included project. Never expose your bot token or Supabase service-role key.
