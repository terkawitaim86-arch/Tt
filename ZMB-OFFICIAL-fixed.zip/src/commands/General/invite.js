const { EmbedBuilder } = require('discord.js');
const config = require('../../config');

module.exports = {
  name: 'invite',
  description: 'Get the bot\'s invite link.',
  category: 'General',
  usage: 'invite',
  aliases: [],
  async execute(message, args, client) {
    const inviteLink = `https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`;

    const embed = new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle(`Invite ${config.botName}`)
      .setDescription(`[Click here to invite me to your server](${inviteLink})`)
      .setThumbnail(client.user.displayAvatarURL({ size: 256 }))
      .setTimestamp();

    return message.reply({ embeds: [embed] });
  },
};
