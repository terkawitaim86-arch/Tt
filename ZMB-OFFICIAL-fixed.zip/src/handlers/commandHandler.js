const fs = require('fs');
const path = require('path');

function loadCommands(client) {
  const commandsPath = path.join(__dirname, '..', 'commands');
  const categoryFolders = fs.readdirSync(commandsPath);
  let count = 0;
  const registeredNames = new Map();

  for (const folder of categoryFolders) {
    const folderPath = path.join(commandsPath, folder);
    if (!fs.statSync(folderPath).isDirectory()) continue;

    const commandFiles = fs.readdirSync(folderPath).filter((file) => file.endsWith('.js'));
    for (const file of commandFiles) {
      const filePath = path.join(folderPath, file);
      let command;
      try {
        command = require(filePath);
      } catch (error) {
        console.error(`[Command Handler] Failed loading ${filePath}:`, error.message);
        continue;
      }

      if (!command.name || typeof command.execute !== 'function') {
        console.warn(`[Command Handler] Skipping invalid command: ${filePath}`);
        continue;
      }

      command.name = String(command.name).toLowerCase();
      command.category = folder;
      const names = [command.name, ...(Array.isArray(command.aliases) ? command.aliases : [])]
        .map((name) => String(name).trim().toLowerCase())
        .filter(Boolean);

      if (registeredNames.has(command.name)) {
        console.warn(`[Command Handler] Duplicate command name "${command.name}" in ${filePath}; skipping.`);
        continue;
      }

      client.commands.set(command.name, command);
      registeredNames.set(command.name, filePath);
      for (const alias of names.slice(1)) {
        if (registeredNames.has(alias)) {
          console.warn(`[Command Handler] Alias "${alias}" in ${filePath} conflicts with ${registeredNames.get(alias)}; skipping alias.`);
          continue;
        }
        client.commands.set(alias, command);
        registeredNames.set(alias, filePath);
      }
      count++;
    }
  }

  console.log(`[Command Handler] Loaded ${count} commands (${client.commands.size} command names and aliases).`);
}

module.exports = { loadCommands };
