const { createClient } = require('@supabase/supabase-js');

// Prefer server-only credentials. Legacy VITE_* variables remain supported for compatibility.
const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  throw new Error(
    'Missing Supabase environment variables. Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY (or the legacy VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY).'
  );
}

if (!process.env.SUPABASE_SERVICE_ROLE_KEY && process.env.VITE_SUPABASE_ANON_KEY) {
  console.warn('[Supabase] Using legacy anon key. Some database operations may fail if table policies restrict anon access. Prefer SUPABASE_SERVICE_ROLE_KEY in the hosting panel; never expose it publicly.');
}

const supabase = createClient(supabaseUrl, supabaseKey);
module.exports = supabase;
