# ZMB Discord Bot

Prefix-only Discord bot built with Node.js, discord.js v14, and Supabase. The default prefix is `,`.

## Requirements
- Node.js 18.18+ (Node.js 20 LTS recommended)
- A Discord application/bot token
- A Supabase project with the SQL migrations in `supabase/migrations/` applied

## Environment variables
Set these in your host's environment/settings panel (or in a local `.env` file):

- `DISCORD_TOKEN` — Discord bot token
- `SUPABASE_URL` — Supabase project URL
- `SUPABASE_SERVICE_ROLE_KEY` — recommended for this server-side bot; keep it secret and never expose it in frontend code
- `SUPABASE_ANON_KEY` — legacy fallback only; review RLS policies carefully if you use it

For compatibility, the older names `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` are also accepted. The service-role key is preferred when configured. Do not commit `.env` or your bot token.

## Run
```sh
npm install
npm start
```

The host startup command can be `npm start` or `node index.js`. Keep the process in the foreground; do not use a web-server-only startup command.

## Discord setup
Enable the **Message Content Intent** and **Server Members Intent** in the Discord Developer Portal. Invite the bot with the permissions required for the features you use (for example, Manage Messages, Manage Roles, Moderate Members, Kick Members, and Ban Members). Ensure the bot's role is above roles it needs to manage.

## Notes
- This bot uses prefix commands only; it does not register slash commands.
- There is no anti-swear filter. Anti-spam is a separate optional feature controlled by the server settings.
- Database-backed features require the supplied Supabase migrations and correct table permissions/RLS policies.
- **Security warning:** some supplied migrations create permissive RLS policies for `anon`/`authenticated` with `USING (true)` and `WITH CHECK (true)`. Do not treat the anon key as a secret or leave broad public policies in place for production. Review and restrict these policies; the server-side service-role key bypasses RLS and must be stored only in the host secret/environment settings.
- If the bot starts but database-backed commands fail, inspect the host logs for the Supabase error and verify the project URL, selected key, migrations, and RLS policies.
