const { EmbedBuilder } = require('discord.js');
const config = require('../../config');
const { getPrefix } = require('../../utils/prefixManager');

module.exports = {
  name: 'help',
  description: 'Shows the command menu or details for a command.',
  category: 'General',
  usage: 'help [command]',
  aliases: ['h', 'commands'],
  async execute(message, args, client) {
    const prefix = message.guild ? await getPrefix(message.guild.id) : config.defaultPrefix;
    if (args[0]) return showCommandHelp(message, args[0], client, prefix);
    return showFullHelp(message, client, prefix);
  },
};

function showFullHelp(message, client, prefix) {
  const embed = new EmbedBuilder()
    .setColor(config.embedColor)
    .setAuthor({ name: `${config.botName} • COMMANDS`, iconURL: client.user.displayAvatarURL() })
    .setDescription(`**${config.tagline || 'Your server, under control.'}**\nUse the menu below to find a command. All commands use the **${prefix}** prefix.\n\n**Need details?** \`${prefix}help <command>\``)
    .setTimestamp();

  const folderToCategory = {
    General: 'General', Moderation: 'Moderation', Logging: 'Logging', Welcome: 'Welcome',
    XP: 'XP & Levels', ReactionRoles: 'Reaction Roles', EmbedBuilder: 'Embed Builder',
    CustomCommands: 'Custom Commands', Utility: 'Utility', Security: 'Security',
  };

  for (const category of config.categories) {
    const commands = [];
    const seen = new Set();
    for (const [, command] of client.commands) {
      const label = command.category || folderToCategory[command.category] || 'General';
      if (label === category.name && !seen.has(command.name)) {
        seen.add(command.name);
        commands.push(`\`${prefix}${command.name}\``);
      }
    }
    if (commands.length) {
      embed.addFields({ name: `${category.emoji}  ${category.name}`, value: commands.join('  ·  ').slice(0, 1024), inline: false });
    }
  }

  embed.setFooter({ text: 'ZMB • Prefix commands only' });
  return message.reply({ embeds: [embed] });
}

function showCommandHelp(message, commandName, client, prefix) {
  const command = client.commands.get(commandName.toLowerCase());
  if (!command) return message.reply(`I couldn't find \`${commandName}\`. Try \`${prefix}help\` to see all commands.`);

  const aliases = command.aliases?.length ? command.aliases.map((alias) => `\`${prefix}${alias}\``).join(', ') : 'None';
  const embed = new EmbedBuilder()
    .setColor(config.embedColor)
    .setAuthor({ name: `${config.botName} • COMMAND INFO`, iconURL: client.user.displayAvatarURL() })
    .setTitle(`${prefix}${command.name}`)
    .setDescription(command.description || 'No description has been added yet.')
    .addFields(
      { name: 'Usage', value: `\`${prefix}${command.usage || command.name}\``, inline: false },
      { name: 'Category', value: command.category || 'General', inline: true },
      { name: 'Aliases', value: aliases, inline: true },
    )
    .setFooter({ text: `Use ${prefix}help to return to the command menu` })
    .setTimestamp();
  return message.reply({ embeds: [embed] });
}
