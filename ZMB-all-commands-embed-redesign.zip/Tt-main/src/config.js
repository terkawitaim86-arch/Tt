module.exports = {
  defaultPrefix: ',',
  botName: 'ZMB',
  tagline: 'Simple commands. Strong moderation.',
  embedColor: 0x5865F2,

  categories: [
    {
      name: 'General',
      emoji: '💠',
      comingSoon: false,
    },
    {
      name: 'Moderation',
      emoji: '🛡️',
      comingSoon: false,
    },
    {
      name: 'Logging',
      emoji: '📋',
      comingSoon: false,
    },
    {
      name: 'Welcome',
      emoji: '👋',
      comingSoon: false,
    },
    {
      name: 'XP & Levels',
      emoji: '⭐',
      comingSoon: false,
    },
    {
      name: 'Reaction Roles',
      emoji: '🎭',
      comingSoon: false,
    },
    {
      name: 'Embed Builder',
      emoji: '🖼️',
      comingSoon: false,
    },
    {
      name: 'Custom Commands',
      emoji: '⌨️',
      comingSoon: false,
    },
    {
      name: 'Utility',
      emoji: '🔧',
      comingSoon: false,
    },
    {
      name: 'Security',
      emoji: '🔒',
      comingSoon: false,
    },
  ],
};
