const fs = require('fs');
const path = require('path');

function loadCommands(client) {
  const commandsPath = path.join(__dirname, '..', 'commands');
  const categoryFolders = fs.readdirSync(commandsPath);

  let count = 0;

  for (const folder of categoryFolders) {
    const folderPath = path.join(commandsPath, folder);
    if (!fs.statSync(folderPath).isDirectory()) continue;

    const commandFiles = fs
      .readdirSync(folderPath)
      .filter((file) => file.endsWith('.js'));

    for (const file of commandFiles) {
      const filePath = path.join(folderPath, file);
      let command;
      try {
        command = require(filePath);
      } catch (error) {
        console.error(`[Command Handler] Failed to load ${filePath}:`, error.message);
        continue;
      }

      if (!command.name || !command.execute) {
        console.warn(`[Command Handler] Skipping invalid command: ${filePath}`);
        continue;
      }

      const categoryLabels = {
        General: 'General',
        Moderation: 'Moderation',
        Logging: 'Logging',
        Welcome: 'Welcome',
        XP: 'XP & Levels',
        ReactionRoles: 'Reaction Roles',
        EmbedBuilder: 'Embed Builder',
        CustomCommands: 'Custom Commands',
        Utility: 'Utility',
        Security: 'Security',
      };
      command.category = categoryLabels[folder] || folder;
      command.name = command.name.toLowerCase();
      client.commands.set(command.name, command);
      count++;

      if (command.aliases && Array.isArray(command.aliases)) {
        for (const alias of command.aliases) {
          if (client.commands.has(alias) && client.commands.get(alias) !== command) {
            console.warn(`[Command Handler] Alias collision for \"${alias}\" in ${filePath}; keeping the existing command.`);
            continue;
          }
          client.commands.set(alias.toLowerCase(), command);
        }
      }
    }
  }

  console.log(`[Command Handler] Loaded ${count} commands.`);
}

module.exports = { loadCommands };
