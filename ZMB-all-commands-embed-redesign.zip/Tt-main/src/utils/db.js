const { createClient } = require('@supabase/supabase-js');

// Supports both standard server-side names and the Vite-prefixed names used by
// the original project, so hosts do not need a frontend/Vite environment.
const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  throw new Error(
    'Missing Supabase environment variables. Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY (recommended for this server-side bot), ' +
    'or SUPABASE_ANON_KEY for legacy setups ' +
    '(or the legacy VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY) in your hosting panel.'
  );
}

module.exports = createClient(supabaseUrl, supabaseKey, {
  auth: { persistSession: false, autoRefreshToken: false },
});
