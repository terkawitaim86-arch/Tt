const {
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle,
  PermissionFlagsBits, MessageFlags
} = require('discord.js');
const config = require('../../config');
const { saveTemplate, getTemplate, listTemplates, deleteTemplate } = require('../../utils/embedStore');

const drafts = new Map();
const TTL = 15 * 60 * 1000;
const MAX_TEXT = 6000;

function freshDraft(guildId, channelId) {
  return { guildId, channelId, data: { color: '#5865F2', fields: [], buttons: [] }, section: 'content', touched: Date.now() };
}
function validUrl(value) {
  if (!value) return true;
  try { const u = new URL(value); return u.protocol === 'https:' || u.protocol === 'http:'; } catch { return false; }
}
function makeEmbed(data) {
  const e = new EmbedBuilder().setColor(data.color || config.embedColor || '#5865F2');
  if (data.title) e.setTitle(data.title.slice(0, 256));
  if (data.description) e.setDescription(data.description.slice(0, 4096));
  if (data.url && validUrl(data.url)) e.setURL(data.url);
  if (data.author) e.setAuthor({ name: data.author.slice(0, 256), ...(data.authorIcon && validUrl(data.authorIcon) ? { iconURL: data.authorIcon } : {}) });
  if (data.footer) e.setFooter({ text: data.footer.slice(0, 2048), ...(data.footerIcon && validUrl(data.footerIcon) ? { iconURL: data.footerIcon } : {}) });
  if (data.thumbnail && validUrl(data.thumbnail)) e.setThumbnail(data.thumbnail);
  if (data.image && validUrl(data.image)) e.setImage(data.image);
  if (data.timestamp) e.setTimestamp();
  if (Array.isArray(data.fields)) {
    for (const f of data.fields.slice(0, 25)) {
      if (f.name && f.value) e.addFields({ name: String(f.name).slice(0, 256), value: String(f.value).slice(0, 1024), inline: !!f.inline });
    }
  }
  return e;
}
function rows(userId, draft) {
  const section = new ActionRowBuilder().addComponents(new StringSelectMenuBuilder()
    .setCustomId(`zmb_embed_section:${userId}`)
    .setPlaceholder('Choose a section to edit')
    .addOptions(
      { label: 'Content', value: 'content', description: 'Title, description and URL', default: draft.section === 'content' },
      { label: 'Appearance', value: 'appearance', description: 'Color and timestamp', default: draft.section === 'appearance' },
      { label: 'Author & Footer', value: 'authorfooter', description: 'Branding and icons', default: draft.section === 'authorfooter' },
      { label: 'Images', value: 'images', description: 'Thumbnail and main image', default: draft.section === 'images' },
      { label: 'Fields', value: 'fields', description: 'Add or remove embed fields', default: draft.section === 'fields' },
      { label: 'Link Buttons', value: 'links', description: 'Add URL buttons below the embed', default: draft.section === 'links' },
    ));
  const edit = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`zmb_embed_edit:${userId}`).setLabel('Edit Section').setStyle(ButtonStyle.Primary).setEmoji('✏️'),
    new ButtonBuilder().setCustomId(`zmb_embed_preview:${userId}`).setLabel('Preview').setStyle(ButtonStyle.Secondary).setEmoji('👁️'),
    new ButtonBuilder().setCustomId(`zmb_embed_send:${userId}`).setLabel('Send').setStyle(ButtonStyle.Success).setEmoji('📤'),
    new ButtonBuilder().setCustomId(`zmb_embed_save:${userId}`).setLabel('Save').setStyle(ButtonStyle.Secondary).setEmoji('💾'),
    new ButtonBuilder().setCustomId(`zmb_embed_cancel:${userId}`).setLabel('Cancel').setStyle(ButtonStyle.Danger).setEmoji('✖️')
  );
  return [section, edit];
}
function dashboard(draft) {
  const d = draft.data;
  const chars = (d.title || '').length + (d.description || '').length + (d.author || '').length + (d.footer || '').length +
    (d.fields || []).reduce((n, f) => n + (f.name || '').length + (f.value || '').length, 0);
  const embed = new EmbedBuilder().setColor(d.color || '#5865F2')
    .setTitle('ZMB • Embed Builder')
    .setDescription('Build a polished embed using the controls below. Your draft is private to your account in this DM.')
    .addFields(
      { name: 'Editing', value: `\`${draft.section}\``, inline: true },
      { name: 'Fields', value: `${(d.fields || []).length}/25`, inline: true },
      { name: 'Link buttons', value: `${(d.buttons || []).length}/5`, inline: true },
      { name: 'Characters', value: `${chars}/${MAX_TEXT}`, inline: true },
      { name: 'Destination', value: `<#${draft.channelId}>`, inline: true }
    )
    .setFooter({ text: 'Draft expires after 15 minutes of inactivity • ZMB' })
    .setTimestamp();
  return embed;
}
function modalFor(userId, draft) {
  const section = draft.section;
  const modal = new ModalBuilder().setCustomId(`zmb_embed_modal:${userId}:${section}`).setTitle(`Edit ${section}`);
  const input = (id, label, value, style = TextInputStyle.Short, required = false, max = 4000) =>
    new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(style).setRequired(required).setMaxLength(max).setValue(value || '');
  let fields = [];
  if (section === 'content') fields = [
    input('title', 'Title', draft.data.title, TextInputStyle.Short, false, 256),
    input('description', 'Description', draft.data.description, TextInputStyle.Paragraph, false, 4000),
    input('url', 'Embed URL (optional)', draft.data.url, TextInputStyle.Short, false, 500),
  ];
  else if (section === 'appearance') fields = [
    input('color', 'Hex color, e.g. #5865F2', draft.data.color || '#5865F2', TextInputStyle.Short, true, 7),
    input('timestamp', 'Timestamp? type yes or no', draft.data.timestamp ? 'yes' : 'no', TextInputStyle.Short, true, 3),
  ];
  else if (section === 'authorfooter') fields = [
    input('author', 'Author text', draft.data.author, TextInputStyle.Short, false, 256),
    input('authorIcon', 'Author icon URL (optional)', draft.data.authorIcon, TextInputStyle.Short, false, 500),
    input('footer', 'Footer text', draft.data.footer, TextInputStyle.Short, false, 2048),
    input('footerIcon', 'Footer icon URL (optional)', draft.data.footerIcon, TextInputStyle.Short, false, 500),
  ];
  else if (section === 'images') fields = [
    input('thumbnail', 'Thumbnail URL', draft.data.thumbnail, TextInputStyle.Short, false, 500),
    input('image', 'Main image URL', draft.data.image, TextInputStyle.Short, false, 500),
  ];
  else if (section === 'fields') fields = [
    input('fieldName', 'Field name (leave blank to remove last field)', '', TextInputStyle.Short, false, 256),
    input('fieldValue', 'Field value', '', TextInputStyle.Paragraph, false, 1024),
    input('inline', 'Inline? yes or no', 'no', TextInputStyle.Short, false, 3),
  ];
  else if (section === 'links') fields = [
    input('buttonLabel', 'Button label (leave blank to remove last)', '', TextInputStyle.Short, false, 80),
    input('buttonUrl', 'Button URL (https://...)', '', TextInputStyle.Short, false, 500),
  ];
  for (const f of fields) modal.addComponents(new ActionRowBuilder().addComponents(f));
  return modal;
}
async function refresh(interaction, draft) {
  draft.touched = Date.now();
  await interaction.update({ embeds: [dashboard(draft)], components: rows(interaction.user.id, draft) });
}
function ownerFromId(id) { return id.split(':').pop(); }
function isOwner(interaction) {
  const id = interaction.customId || '';
  return id.split(':')[1] === interaction.user.id;
}

module.exports = {
  name: 'embed',
  description: 'Interactive embed builder.',
  category: 'Embed Builder',
  usage: ',embed create',
  aliases: ['embedbuilder'],
  async execute(message, args) {
    if (!message.guild || !message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
      return message.reply({ content: 'You need **Manage Messages** permission to use the embed builder.' });
    }
    const sub = (args[0] || 'help').toLowerCase();
    if (sub === 'create') {
      const draft = freshDraft(message.guild.id, message.channel.id);
      drafts.set(message.author.id, draft);
      try {
        const dm = await message.author.createDM();
        await dm.send({ embeds: [dashboard(draft)], components: rows(message.author.id, draft) });
        if (message.deletable) await message.delete().catch(() => {});
        return;
      } catch {
        drafts.delete(message.author.id);
        return message.reply('I could not DM you. Enable direct messages from server members, then run `,embed create` again.');
      }
    }
    if (sub === 'save') {
      const name = args[1]?.toLowerCase();
      const draft = drafts.get(message.author.id);
      if (!name || !draft) return message.reply('Start a draft with `,embed create`, then use `,embed save <name>`.');
      const ok = await saveTemplate(message.guild.id, name, draft.data);
      return message.reply(ok ? `Saved embed template **${name}**.` : 'Could not save the template. Check the database configuration.');
    }
    if (sub === 'load') {
      const name = args[1]?.toLowerCase();
      const data = name ? await getTemplate(message.guild.id, name) : null;
      if (!data) return message.reply('Template not found. Use `,embed list` to see saved templates.');
      const draft = freshDraft(message.guild.id, message.channel.id);
      draft.data = { fields: [], buttons: [], ...data };
      drafts.set(message.author.id, draft);
      try {
        const dm = await message.author.createDM();
        await dm.send({ embeds: [dashboard(draft)], components: rows(message.author.id, draft) });
        return message.reply(`Loaded **${name}** into your private builder.`);
      } catch { return message.reply('I could not DM you. Enable DMs and try again.'); }
    }
    if (sub === 'list') {
      const names = await listTemplates(message.guild.id);
      return message.reply({ embeds: [new EmbedBuilder().setColor(config.embedColor || '#5865F2').setTitle('Saved Embed Templates').setDescription(names.length ? names.map(n => `• \`${n}\``).join('\n') : 'No templates saved yet.').setFooter({ text: 'ZMB Embed Builder' })] });
    }
    if (sub === 'delete') {
      const name = args[1]?.toLowerCase();
      if (!name) return message.reply('Usage: `,embed delete <name>`');
      const ok = await deleteTemplate(message.guild.id, name);
      return message.reply(ok ? `Deleted template **${name}**.` : `No template named **${name}** was found.`);
    }
    return message.reply({ embeds: [new EmbedBuilder().setColor(config.embedColor || '#5865F2').setTitle('ZMB • Embed Builder').setDescription('Create and customize embeds without JSON.').addFields(
      { name: 'Create', value: '`,embed create` — open the interactive private builder' },
      { name: 'Templates', value: '`,embed save <name>` • `,embed load <name>` • `,embed list` • `,embed delete <name>`' }
    ).setFooter({ text: 'ZMB • Staff tools' })] });
  },
  async handleInteraction(interaction) {
    const id = interaction.customId || '';
    if (!id.startsWith('zmb_embed_')) return false;
    const parts = id.split(':');
    const ownerId = parts[1];
    if (ownerId !== interaction.user.id) {
      await interaction.reply({ content: 'This embed draft belongs to someone else.', ephemeral: true }).catch(() => {});
      return true;
    }
    const draft = drafts.get(ownerId);
    if (!draft) {
      await interaction.reply({ content: 'This draft expired. Run `,embed create` again.', ephemeral: true }).catch(() => {});
      return true;
    }
    draft.touched = Date.now();
    if (interaction.isStringSelectMenu() && id.startsWith('zmb_embed_section:')) {
      draft.section = interaction.values[0];
      await refresh(interaction, draft);
      return true;
    }
    if (interaction.isButton()) {
      if (id.startsWith('zmb_embed_edit:')) {
        await interaction.showModal(modalFor(ownerId, draft)); return true;
      }
      if (id.startsWith('zmb_embed_preview:')) {
        const components = [];
        for (const b of (draft.data.buttons || []).slice(0, 5)) {
          if (b.label && validUrl(b.url)) components.push(new ButtonBuilder().setLabel(b.label).setStyle(ButtonStyle.Link).setURL(b.url));
        }
        const rowsOut = [];
        for (let i = 0; i < components.length; i += 5) rowsOut.push(new ActionRowBuilder().addComponents(components.slice(i, i + 5)));
        await interaction.reply({ embeds: [makeEmbed(draft.data)], components: rowsOut, ephemeral: true }); return true;
      }
      if (id.startsWith('zmb_embed_send:')) {
        const channel = interaction.client.channels.cache.get(draft.channelId);
        if (!channel || !channel.isTextBased()) {
          await interaction.reply({ content: 'The original destination is unavailable. Start a new draft from the target channel.', ephemeral: true }); return true;
        }
        const linkButtons = (draft.data.buttons || []).filter(b => b.label && validUrl(b.url)).slice(0, 5);
        const outRows = linkButtons.length ? [new ActionRowBuilder().addComponents(linkButtons.map(b => new ButtonBuilder().setLabel(b.label).setStyle(ButtonStyle.Link).setURL(b.url)))] : [];
        await channel.send({ embeds: [makeEmbed(draft.data)], components: outRows });
        await interaction.update({ embeds: [dashboard(draft).setTitle('Embed sent successfully').setDescription(`Your embed was sent to <#${draft.channelId}>.`)], components: [] });
        drafts.delete(ownerId); return true;
      }
      if (id.startsWith('zmb_embed_save:')) {
        const modal = new ModalBuilder().setCustomId(`zmb_embed_savemodal:${ownerId}`).setTitle('Save Embed Template')
          .addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('name').setLabel('Template name').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(40)));
        await interaction.showModal(modal); return true;
      }
      if (id.startsWith('zmb_embed_cancel:')) {
        drafts.delete(ownerId);
        await interaction.update({ content: 'Embed draft cancelled.', embeds: [], components: [] }); return true;
      }
    }
    if (interaction.isModalSubmit() && id.startsWith('zmb_embed_savemodal:')) {
      const name = interaction.fields.getTextInputValue('name').trim().toLowerCase().replace(/[^a-z0-9_-]/g, '-').slice(0, 40);
      const ok = await saveTemplate(draft.guildId, name, draft.data);
      await interaction.reply({ content: ok ? `Saved template **${name}**.` : 'Could not save template. Check database configuration.', ephemeral: true }); return true;
    }
    if (interaction.isModalSubmit() && id.startsWith('zmb_embed_modal:')) {
      const section = parts[2];
      const get = (key) => { try { return interaction.fields.getTextInputValue(key).trim(); } catch { return undefined; } };
      const d = draft.data;
      if (section === 'content') {
        for (const key of ['title', 'description', 'url']) { const val = get(key); if (val !== undefined) d[key] = val || undefined; }
        if (d.url && !validUrl(d.url)) return interaction.reply({ content: 'The embed URL must start with http:// or https://.', ephemeral: true });
      } else if (section === 'appearance') {
        const color = get('color');
        if (!/^#?[0-9a-fA-F]{6}$/.test(color || '')) return interaction.reply({ content: 'Enter a valid hex color, e.g. `#5865F2`.', ephemeral: true });
        d.color = color.startsWith('#') ? color : `#${color}`;
        d.timestamp = ['yes', 'y', 'true'].includes((get('timestamp') || '').toLowerCase());
      } else if (section === 'authorfooter') {
        for (const key of ['author', 'authorIcon', 'footer', 'footerIcon']) { const val = get(key); if (val !== undefined) d[key] = val || undefined; }
        if (!validUrl(d.authorIcon) || !validUrl(d.footerIcon)) return interaction.reply({ content: 'Icon URLs must use http:// or https://.', ephemeral: true });
      } else if (section === 'images') {
        for (const key of ['thumbnail', 'image']) { const val = get(key); if (val !== undefined) d[key] = val || undefined; }
        if (!validUrl(d.thumbnail) || !validUrl(d.image)) return interaction.reply({ content: 'Image URLs must use http:// or https://.', ephemeral: true });
      } else if (section === 'fields') {
        const name = get('fieldName'), value = get('fieldValue');
        if (name) {
          if (!value) return interaction.reply({ content: 'A field value is required when adding a field.', ephemeral: true });
          if (d.fields.length >= 25) return interaction.reply({ content: 'Discord allows up to 25 fields per embed.', ephemeral: true });
          d.fields.push({ name, value, inline: ['yes', 'y', 'true'].includes((get('inline') || '').toLowerCase()) });
        } else if (d.fields.length) d.fields.pop();
      } else if (section === 'links') {
        const label = get('buttonLabel'), url = get('buttonUrl');
        if (label) {
          if (!validUrl(url) || !url) return interaction.reply({ content: 'Enter a valid http:// or https:// button URL.', ephemeral: true });
          if (d.buttons.length >= 5) return interaction.reply({ content: 'Discord allows up to 5 link buttons in this builder.', ephemeral: true });
          d.buttons.push({ label, url });
        } else if (d.buttons.length) d.buttons.pop();
      }
      if (interaction.message) {
        await interaction.message.edit({ embeds: [dashboard(draft)], components: rows(ownerId, draft) }).catch(() => {});
      }
      await interaction.reply({ content: 'Draft updated.', ephemeral: true });
      return true;
    }
    return true;
  }
};

setInterval(() => {
  const now = Date.now();
  for (const [userId, draft] of drafts) if (now - draft.touched > TTL) drafts.delete(userId);
}, 60_000).unref();
