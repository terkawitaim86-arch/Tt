# ZMB Bot — Audit and Redesign Notes

## Changes made

- Rebuilt `,help` into a mobile-friendlier two-embed command guide with clearer grouping, command counts, aliases, and command-specific usage details.
- Fixed help output so long category lists are split rather than silently truncated at Discord's embed field limit.
- Hardened command loading against duplicate command names and case-insensitive alias collisions.
- Fixed `,clear` to use Discord's valid message-fetch limit and check that the bot itself has Manage Messages permission in the channel.
- Fixed XP cooldown tracking so a member's cooldown is scoped to a server instead of sharing one cooldown across all servers.
- Fixed XP min/max validation and allowed the documented zero-second cooldown.
- Made `,antispam` accurately display its status and support `,antispam off`; anti-swear filtering is not included.
- Added custom-embed validation for colors, URLs, fields, text lengths, and malformed saved templates, with clearer error messages.
- Improved startup validation so missing Discord/Supabase environment variables produce readable host logs before loading the bot.
- Added clean shutdown handling for SIGTERM/SIGINT.
- Added a Supabase hardening migration that removes broad public policies and revokes `anon`/`authenticated` access to bot-owned tables.
- Updated hosting and security setup instructions.

## Validation performed

- All JavaScript files passed `node --check` syntax validation.
- The dependency installation attempt did not finish within the available execution window, so runtime tests with installed dependencies could not be completed here.
- The bot has not been connected to a live Discord server or Supabase project in this audit. Live command behavior, permissions, and database connectivity must still be verified after deployment.

## Before deploying

1. Set `DISCORD_TOKEN`, `SUPABASE_URL`, and `SUPABASE_SERVICE_ROLE_KEY` in the host's secret/environment settings.
2. Apply the SQL migrations in filename order, including `20261101000000_lock_down_bot_tables.sql`.
3. Use the service-role key only on the server/host. Never commit it or put it in frontend variables.
4. In Discord Developer Portal, enable Message Content Intent and Server Members Intent if required by your bot features.
5. Give the bot only the permissions it needs, and keep its role above roles it must assign or moderate.
6. Start with `npm start` and inspect logs; test help, clear, moderation, logging, XP, welcome, reaction roles, and embed builder in a test server.

## Important compatibility note

The hardening migration intentionally disables direct `anon`/`authenticated` table access. The bot should use `SUPABASE_SERVICE_ROLE_KEY`. Existing projects must apply the new migration; simply replacing source files does not change an already-running Supabase database.
