# ZMB Discord Bot

ZMB is a prefix-only Discord bot built with Node.js, discord.js v14, and Supabase. The default prefix is `,`. It includes moderation, logging, welcome messages, XP/levels, reaction roles, custom embeds, custom commands, and utilities.

## Requirements
- Node.js 20 LTS recommended (18.18+ supported)
- A Discord bot token
- A Supabase project with the SQL migrations in `supabase/migrations/` applied

## Environment variables
Configure these in your host's environment/settings panel or a local `.env` file:

- `DISCORD_TOKEN` — Discord bot token
- `SUPABASE_URL` — Supabase project URL
- `SUPABASE_SERVICE_ROLE_KEY` — recommended server-side key; treat as a secret
- `SUPABASE_ANON_KEY` — legacy fallback only; it will not have access after the included hardening migration unless you explicitly configure safe policies

Legacy `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` names are accepted for compatibility. Never commit a real `.env` file or bot token. Never put the service-role key in frontend code.

## Run locally or on a host
```sh
npm install
npm start
```

Use `npm start` or `node index.js` as the startup command. The bot is a long-running worker; a static-site or frontend-only host will not keep it online.

## Discord Developer Portal
Enable **Message Content Intent** and **Server Members Intent** if you use prefix commands and member events. Invite the bot with only the permissions needed for enabled features. Put the bot's role above roles it must assign or moderate.

## Features and behavior
- Prefix commands only; no slash commands are registered.
- Anti-swear filtering is not included. Anti-spam is a separate feature and should only be enabled if configured intentionally.
- XP cooldowns are tracked per server and member while the process is running.
- Database-backed features need the migrations and correct database access policies.

## Security note
The original setup migrations included permissive RLS policies. Apply **all** migrations, including `20261101000000_lock_down_bot_tables.sql`, before production use. The hardening migration revokes table access from `anon` and `authenticated` and removes policies from bot-owned tables; use `SUPABASE_SERVICE_ROLE_KEY` from the host's secret/environment settings. This key bypasses RLS and must never be committed or exposed in frontend code.

## Troubleshooting
- **Bot does not start:** check `DISCORD_TOKEN`, the Supabase variables, Node.js version, and host startup logs.
- **Bot is online but commands do not respond:** check Message Content Intent, the configured prefix, and the bot's channel permissions.
- **Database commands fail:** verify the Supabase URL/key, migrations, table names, and RLS policies.
