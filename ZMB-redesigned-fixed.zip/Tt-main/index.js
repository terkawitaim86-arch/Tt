require('dotenv').config();

let botClient = null;

// Process-level error handlers — log failures clearly for hosting dashboards.
process.on('uncaughtException', (err, origin) => {
  console.error('[FATAL] Uncaught Exception:', err.message);
  if (err.stack) console.error(err.stack);
  console.error('[FATAL] Origin:', origin);
});

process.on('unhandledRejection', (reason) => {
  console.error('[FATAL] Unhandled Promise Rejection:', reason);
});

async function shutdown(signal) {
  console.log(`[Process] ${signal} received — shutting down cleanly.`);
  if (botClient) botClient.destroy();
  process.exit(0);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

async function boot() {
  if (!process.env.DISCORD_TOKEN) {
    throw new Error('Missing DISCORD_TOKEN. Add your Discord bot token in the hosting environment settings.');
  }

  const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
  const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY;
  if (!supabaseUrl || !supabaseKey) {
    throw new Error('Missing Supabase configuration. Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in the host environment. Do not commit secrets to GitHub.');
  }

  // Load the bot only after environment validation so startup errors are readable.
  const { startBot, client } = require('./src/bot');
  botClient = client;
  await startBot();
}

boot().catch((error) => {
  console.error('[Startup] ZMB could not start:', error.message);
  process.exitCode = 1;
});
