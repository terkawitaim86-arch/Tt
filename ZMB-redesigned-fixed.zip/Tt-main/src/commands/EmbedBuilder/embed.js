const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../../config');
const { saveTemplate, getTemplate, listTemplates, deleteTemplate } = require('../../utils/embedStore');

function buildEmbedFromData(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) {
    throw new Error('Embed data must be a JSON object.');
  }
  const embed = new EmbedBuilder();
  if (data.title) {
    if (String(data.title).length > 256) throw new Error('Title must be 256 characters or fewer.');
    embed.setTitle(String(data.title));
  }
  if (data.description) {
    if (String(data.description).length > 4096) throw new Error('Description must be 4,096 characters or fewer.');
    embed.setDescription(String(data.description));
  }
  if (data.color) {
    const color = String(data.color).replace(/^#/, '');
    if (!/^[0-9a-fA-F]{6}$/.test(color)) throw new Error('Color must be a six-digit hex value, for example #5865F2.');
    embed.setColor(parseInt(color, 16));
  } else embed.setColor(config.embedColor);
  if (data.thumbnail) {
    if (!isHttpUrl(data.thumbnail)) throw new Error('Thumbnail must be a valid http:// or https:// URL.');
    embed.setThumbnail(data.thumbnail);
  }
  if (data.image) {
    if (!isHttpUrl(data.image)) throw new Error('Image must be a valid http:// or https:// URL.');
    embed.setImage(data.image);
  }
  if (data.footer) {
    if (String(data.footer).length > 2048) throw new Error('Footer must be 2,048 characters or fewer.');
    embed.setFooter({ text: String(data.footer) });
  }
  if (data.author) {
    if (String(data.author).length > 256) throw new Error('Author must be 256 characters or fewer.');
    embed.setAuthor({ name: String(data.author) });
  }
  if (data.fields !== undefined) {
    if (!Array.isArray(data.fields)) throw new Error('Fields must be an array.');
    if (data.fields.length > 25) throw new Error('An embed can contain at most 25 fields.');
    for (const f of data.fields) {
      if (!f || !String(f.name || '').trim() || !String(f.value || '').trim()) {
        throw new Error('Every field needs both a name and a value.');
      }
      if (String(f.name).length > 256 || String(f.value).length > 1024) {
        throw new Error('Field names must be 256 characters or fewer and field values 1,024 characters or fewer.');
      }
      embed.addFields({ name: String(f.name), value: String(f.value), inline: Boolean(f.inline) });
    }
  }
  if (data.timestamp) embed.setTimestamp();
  const totalText = [data.title, data.description, data.footer, data.author, ...(data.fields || []).flatMap((field) => [field.name, field.value])].filter(Boolean).join('').length;
  if (totalText > 6000) throw new Error('The combined embed text must be 6,000 characters or fewer.');
  return embed;
}

function isHttpUrl(value) {
  try {
    const url = new URL(String(value));
    return url.protocol === 'https:' || url.protocol === 'http:';
  } catch {
    return false;
  }
}

module.exports = {
  name: 'embed',
  description: 'Create, save, and send custom embeds.',
  category: 'Embed Builder',
  usage: 'embed <send|save|load|list|delete> [args...]',
  aliases: ['embedbuilder'],
  async execute(message, args, client) {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
      return message.reply('You need the **Manage Messages** permission to use this command.');
    }

    const subcommand = args[0]?.toLowerCase();

    if (subcommand === 'send') {
      const jsonText = args.slice(1).join(' ');
      if (!jsonText) {
        return message.reply('Usage: `embed send {"title":"...", "description":"...", "color":"#5865F2", "thumbnail":"url", "image":"url", "footer":"text", "fields":[{"name":"...","value":"..."}]}`');
      }

      try {
        const data = JSON.parse(jsonText);
        const embed = buildEmbedFromData(data);
        if (message.deletable) message.delete().catch(() => {});
        return message.channel.send({ embeds: [embed] });
      } catch (error) {
        return message.reply(`Could not build that embed: ${error.message}`);
      }
    }

    if (subcommand === 'save') {
      const name = args[1]?.toLowerCase();
      const jsonText = args.slice(2).join(' ');

      if (!name || !jsonText) {
        return message.reply('Usage: `embed save <name> {"title":"...", ...}`');
      }

      try {
        const data = JSON.parse(jsonText);
        buildEmbedFromData(data); // Validate before saving so broken templates cannot be stored.
        const success = await saveTemplate(message.guild.id, name, data);
        if (!success) return message.reply('Failed to save template.');
        return message.reply(`Embed template **${name}** saved.`);
      } catch (error) {
        return message.reply(`Could not build that embed: ${error.message}`);
      }
    }

    if (subcommand === 'load') {
      const name = args[1]?.toLowerCase();
      if (!name) {
        return message.reply('Usage: `embed load <name>`');
      }

      const data = await getTemplate(message.guild.id, name);
      if (!data) {
        return message.reply(`No template named **${name}** found.`);
      }

      try {
        const embed = buildEmbedFromData(data);
        if (message.deletable) message.delete().catch(() => {});
        return message.channel.send({ embeds: [embed] });
      } catch (error) {
        return message.reply(`That saved template is invalid: ${error.message}`);
      }
    }

    if (subcommand === 'list') {
      const templates = await listTemplates(message.guild.id);
      if (templates.length === 0) {
        return message.reply('No embed templates saved yet.');
      }

      const embed = new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle('Saved Embed Templates')
        .setDescription(templates.map((t) => `\`${t}\``).join('\n'))
        .setTimestamp();

      return message.reply({ embeds: [embed] });
    }

    if (subcommand === 'delete') {
      const name = args[1]?.toLowerCase();
      if (!name) {
        return message.reply('Usage: `embed delete <name>`');
      }

      const success = await deleteTemplate(message.guild.id, name);
      if (!success) return message.reply(`No template named **${name}** found.`);
      return message.reply(`Embed template **${name}** deleted.`);
    }

    return message.reply(
      'Usage:\n' +
      '`embed send {"title":"...","description":"..."}` — send an embed\n' +
      '`embed save <name> {json}` — save a template\n' +
      '`embed load <name>` — load and send a saved template\n' +
      '`embed list` — list saved templates\n' +
      '`embed delete <name>` — delete a template'
    );
  },
};
