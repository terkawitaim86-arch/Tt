const { EmbedBuilder } = require('discord.js');
const config = require('../../config');
const { getPrefix } = require('../../utils/prefixManager');

module.exports = {
  name: 'help',
  description: 'Shows the command menu or details for a command.',
  category: 'General',
  usage: 'help [command]',
  aliases: ['h', 'commands'],
  async execute(message, args, client) {
    const prefix = message.guild ? await getPrefix(message.guild.id) : config.defaultPrefix;
    if (args[0]) return showCommandHelp(message, args[0], client, prefix);
    return showFullHelp(message, client, prefix);
  },
};

const CATEGORY_ORDER = [
  ['General', '💠', 'General'],
  ['Moderation', '🛡️', 'Moderation'],
  ['Logging', '📋', 'Logging'],
  ['Welcome', '👋', 'Welcome'],
  ['XP & Levels', '⭐', 'XP'],
  ['Reaction Roles', '🎭', 'ReactionRoles'],
  ['Embed Builder', '🖼️', 'EmbedBuilder'],
  ['Custom Commands', '⌨️', 'CustomCommands'],
  ['Utility', '🔧', 'Utility'],
  ['Security', '🔒', 'Security'],
];

function uniqueCommands(client) {
  const seen = new Set();
  return [...client.commands.values()].filter((command) => {
    if (seen.has(command.name)) return false;
    seen.add(command.name);
    return true;
  });
}

function showFullHelp(message, client, prefix) {
  const commands = uniqueCommands(client);
  const sections = CATEGORY_ORDER.map(([name, emoji, folder]) => ({
    name,
    emoji,
    commands: commands.filter((command) => command.category === name || command.category === folder),
  })).filter((section) => section.commands.length);

  // Two short embeds are much easier to scan on mobile than one long, crowded embed.
  const splitAt = Math.ceil(sections.length / 2);
  const groups = [sections.slice(0, splitAt), sections.slice(splitAt)];
  const embeds = groups.filter((group) => group.length).map((group, index) => {
    const embed = new EmbedBuilder()
      .setColor(config.embedColor)
      .setAuthor({ name: `${config.botName}  /  COMMAND GUIDE`, iconURL: client.user.displayAvatarURL() })
      .setDescription(index === 0
        ? `**${config.tagline}**\nA clean guide to every command.\n\n**Prefix**  \`${prefix}\`\n**Command details**  \`${prefix}help <command>\``
        : `**More commands**\nUse \`${prefix}help <command>\` for usage, aliases and details.`)
      .setFooter({ text: `${config.botName} • ${commands.length} commands • Prefix commands only` });

    for (const section of group) {
      const commandList = section.commands
        .sort((a, b) => a.name.localeCompare(b.name))
        .map((command) => `\`${prefix}${command.name}\``)
        .join('  ·  ');
      // Discord field values have a 1,024-character limit. Split safely instead of truncating commands.
      const chunks = splitText(commandList, 950);
      chunks.forEach((chunk, chunkIndex) => {
        embed.addFields({
          name: `${section.emoji}  ${section.name}${chunkIndex ? ' (continued)' : ''}`,
          value: chunk || 'No commands available.',
          inline: false,
        });
      });
    }
    return embed;
  });

  return message.reply({ embeds });
}

function splitText(text, maxLength) {
  const parts = [];
  let current = '';
  for (const item of text.split('  ·  ')) {
    const next = current ? `${current}  ·  ${item}` : item;
    if (next.length > maxLength && current) {
      parts.push(current);
      current = item;
    } else {
      current = next;
    }
  }
  if (current) parts.push(current);
  return parts;
}

function showCommandHelp(message, commandName, client, prefix) {
  const command = client.commands.get(commandName.toLowerCase());
  if (!command) {
    return message.reply(`I couldn't find \`${commandName}\`. Use \`${prefix}help\` to browse commands.`);
  }

  const aliases = command.aliases?.length
    ? command.aliases.map((alias) => `\`${prefix}${alias}\``).join(', ')
    : 'None';
  const embed = new EmbedBuilder()
    .setColor(config.embedColor)
    .setAuthor({ name: `${config.botName}  /  COMMAND DETAILS`, iconURL: client.user.displayAvatarURL() })
    .setTitle(`${prefix}${command.name}`)
    .setDescription(command.description || 'No description has been added yet.')
    .addFields(
      { name: 'Usage', value: `\`${prefix}${command.usage || command.name}\``, inline: false },
      { name: 'Category', value: command.category || 'General', inline: true },
      { name: 'Aliases', value: aliases, inline: true },
    )
    .setFooter({ text: `Use ${prefix}help to return to the command guide` })
    .setTimestamp();
  return message.reply({ embeds: [embed] });
}
