const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../../config');
const { getSettings, updateSettings } = require('../../utils/guildSettings');

module.exports = {
  name: 'antispam',
  description: 'View or disable the optional anti-spam protection.',
  category: 'Security',
  usage: 'antispam [off]',
  aliases: ['spamconfig'],
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
      return message.reply('You need the **Manage Server** permission to use this command.');
    }

    const settings = await getSettings(message.guild.id);
    if (args[0]?.toLowerCase() === 'off') {
      const saved = await updateSettings(message.guild.id, { anti_spam_enabled: false });
      if (!saved) return message.reply('I could not update the anti-spam setting. Check the database connection and try again.');
      return message.reply({ embeds: [
        new EmbedBuilder()
          .setColor(config.embedColor)
          .setTitle('🔒 Anti-Spam Disabled')
          .setDescription('Optional anti-spam enforcement is now **off** for this server. The anti-swear filter is not included in ZMB.')
          .setFooter({ text: `${config.botName} • Security settings` })
          .setTimestamp(),
      ] });
    }

    return message.reply({ embeds: [
      new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle('🔒 Anti-Spam Settings')
        .setDescription(`Current status: **${settings.anti_spam_enabled ? 'Enabled' : 'Disabled'}**\n\nUse \`,antispam off\` to disable optional anti-spam enforcement. Anti-swear filtering is not included.`)
        .setFooter({ text: `${config.botName} • Security settings` })
        .setTimestamp(),
    ] });
  },
};
