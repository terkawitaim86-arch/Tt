-- Lock down bot-owned tables. The bot should connect using SUPABASE_SERVICE_ROLE_KEY
-- stored only in the host's environment. This migration removes permissive public
-- policies from earlier setup migrations and revokes anon/authenticated table access.

ALTER TABLE IF EXISTS public.guild_prefixes ENABLE ROW LEVEL SECURITY;
REVOKE ALL PRIVILEGES ON TABLE public.guild_prefixes FROM anon, authenticated;
DO $$ DECLARE policy_row record; BEGIN
  IF to_regclass('public.guild_prefixes') IS NOT NULL THEN
    FOR policy_row IN SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'guild_prefixes' LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.guild_prefixes', policy_row.policyname);
    END LOOP;
  END IF;
END $$;

ALTER TABLE IF EXISTS public.moderation_warnings ENABLE ROW LEVEL SECURITY;
REVOKE ALL PRIVILEGES ON TABLE public.moderation_warnings FROM anon, authenticated;
DO $$ DECLARE policy_row record; BEGIN
  IF to_regclass('public.moderation_warnings') IS NOT NULL THEN
    FOR policy_row IN SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'moderation_warnings' LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.moderation_warnings', policy_row.policyname);
    END LOOP;
  END IF;
END $$;

ALTER TABLE IF EXISTS public.moderation_logs ENABLE ROW LEVEL SECURITY;
REVOKE ALL PRIVILEGES ON TABLE public.moderation_logs FROM anon, authenticated;
DO $$ DECLARE policy_row record; BEGIN
  IF to_regclass('public.moderation_logs') IS NOT NULL THEN
    FOR policy_row IN SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'moderation_logs' LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.moderation_logs', policy_row.policyname);
    END LOOP;
  END IF;
END $$;

ALTER TABLE IF EXISTS public.guild_settings ENABLE ROW LEVEL SECURITY;
REVOKE ALL PRIVILEGES ON TABLE public.guild_settings FROM anon, authenticated;
DO $$ DECLARE policy_row record; BEGIN
  IF to_regclass('public.guild_settings') IS NOT NULL THEN
    FOR policy_row IN SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'guild_settings' LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.guild_settings', policy_row.policyname);
    END LOOP;
  END IF;
END $$;

ALTER TABLE IF EXISTS public.xp_data ENABLE ROW LEVEL SECURITY;
REVOKE ALL PRIVILEGES ON TABLE public.xp_data FROM anon, authenticated;
DO $$ DECLARE policy_row record; BEGIN
  IF to_regclass('public.xp_data') IS NOT NULL THEN
    FOR policy_row IN SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'xp_data' LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.xp_data', policy_row.policyname);
    END LOOP;
  END IF;
END $$;

ALTER TABLE IF EXISTS public.level_rewards ENABLE ROW LEVEL SECURITY;
REVOKE ALL PRIVILEGES ON TABLE public.level_rewards FROM anon, authenticated;
DO $$ DECLARE policy_row record; BEGIN
  IF to_regclass('public.level_rewards') IS NOT NULL THEN
    FOR policy_row IN SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'level_rewards' LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.level_rewards', policy_row.policyname);
    END LOOP;
  END IF;
END $$;

ALTER TABLE IF EXISTS public.reaction_roles ENABLE ROW LEVEL SECURITY;
REVOKE ALL PRIVILEGES ON TABLE public.reaction_roles FROM anon, authenticated;
DO $$ DECLARE policy_row record; BEGIN
  IF to_regclass('public.reaction_roles') IS NOT NULL THEN
    FOR policy_row IN SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'reaction_roles' LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.reaction_roles', policy_row.policyname);
    END LOOP;
  END IF;
END $$;

ALTER TABLE IF EXISTS public.button_roles ENABLE ROW LEVEL SECURITY;
REVOKE ALL PRIVILEGES ON TABLE public.button_roles FROM anon, authenticated;
DO $$ DECLARE policy_row record; BEGIN
  IF to_regclass('public.button_roles') IS NOT NULL THEN
    FOR policy_row IN SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'button_roles' LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.button_roles', policy_row.policyname);
    END LOOP;
  END IF;
END $$;

ALTER TABLE IF EXISTS public.custom_commands ENABLE ROW LEVEL SECURITY;
REVOKE ALL PRIVILEGES ON TABLE public.custom_commands FROM anon, authenticated;
DO $$ DECLARE policy_row record; BEGIN
  IF to_regclass('public.custom_commands') IS NOT NULL THEN
    FOR policy_row IN SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'custom_commands' LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.custom_commands', policy_row.policyname);
    END LOOP;
  END IF;
END $$;

ALTER TABLE IF EXISTS public.embed_templates ENABLE ROW LEVEL SECURITY;
REVOKE ALL PRIVILEGES ON TABLE public.embed_templates FROM anon, authenticated;
DO $$ DECLARE policy_row record; BEGIN
  IF to_regclass('public.embed_templates') IS NOT NULL THEN
    FOR policy_row IN SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'embed_templates' LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.embed_templates', policy_row.policyname);
    END LOOP;
  END IF;
END $$;

ALTER TABLE IF EXISTS public.reminders ENABLE ROW LEVEL SECURITY;
REVOKE ALL PRIVILEGES ON TABLE public.reminders FROM anon, authenticated;
DO $$ DECLARE policy_row record; BEGIN
  IF to_regclass('public.reminders') IS NOT NULL THEN
    FOR policy_row IN SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'reminders' LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.reminders', policy_row.policyname);
    END LOOP;
  END IF;
END $$;

ALTER TABLE IF EXISTS public.afk_status ENABLE ROW LEVEL SECURITY;
REVOKE ALL PRIVILEGES ON TABLE public.afk_status FROM anon, authenticated;
DO $$ DECLARE policy_row record; BEGIN
  IF to_regclass('public.afk_status') IS NOT NULL THEN
    FOR policy_row IN SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'afk_status' LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.afk_status', policy_row.policyname);
    END LOOP;
  END IF;
END $$;

ALTER TABLE IF EXISTS public.jail_records ENABLE ROW LEVEL SECURITY;
REVOKE ALL PRIVILEGES ON TABLE public.jail_records FROM anon, authenticated;
DO $$ DECLARE policy_row record; BEGIN
  IF to_regclass('public.jail_records') IS NOT NULL THEN
    FOR policy_row IN SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'jail_records' LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.jail_records', policy_row.policyname);
    END LOOP;
  END IF;
END $$;
